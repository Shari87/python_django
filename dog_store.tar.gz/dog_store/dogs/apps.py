from django.apps import AppConfig


class DogsConfig(AppConfig):
    name = 'dogs'
